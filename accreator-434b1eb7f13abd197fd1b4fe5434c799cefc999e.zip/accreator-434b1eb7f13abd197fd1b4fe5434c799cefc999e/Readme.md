AntiContainer Creator
=====================

Simple, locally run WebApp to help creating AntiContainer (Sandbox) plugins.

Installation
------------
Check out and open index.html.

Creating Plugins
----------------

Fill in the fields. The resulting plugin will be auto-updated. You may then copy the result into a .json file.

Editing Plugins
---------------

Drag and drop the json file onto the web page. The contents will then be loaded.

Getting the results
-------------------

You may always CTRL-A/C the plugin source, but the whole document also supports Drag and drop.


TODO
----

* Integrate the stuff with AntiContainer itself.
* Support the other plugin types.
* RegEx helpers

License
-------

MPL 1.1/GPL 2.0/LGPL 2.1